<?php
error_reporting(E_ALL & ~E_NOTICE);
require 'vendor/autoload.php';
use GuzzleHttp\Client;

$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();

$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));
include 'config.php';

//$store = 'contractorscommercial-com.myshopify.com'; 
$select = $db->query("SELECT access_token FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$access_token = $user->access_token;
$client = new Client();
$loader = new Twig_Loader_Filesystem('templates');
$twig = new Twig_Environment($loader, [
   'cache' => 'cache',
   'debug' => true
]);
$shop_domain = $_POST['X-Shopify-Shop-Domain'];
$json_decode = json_encode($_POST);
$json_decode2 = json_encode($_GET);


  // The raw contents of the post body
$data = file_get_contents('php://input');
$get_domain = json_decode($data, true);
$store = $get_domain['domain'];
$select = $db->query("SELECT access_token,id FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$access_token = $user->access_token;
$store_access_id = $user->id;

$ans_sql = "DELETE FROM categories_ans WHERE store_access_id ='".$store_access_id."'";
$ans_resul=mysqli_query($con,$ans_sql);
$cat_result = "DELETE FROM ques_categories WHERE store_access_id ='".$store_access_id."'";			
$cat_id_resul=mysqli_query($con,$cat_result);
		
///////////////////////////////
	$response_1 = $client->request(
		'GET', 
		"https://{$store}/admin/themes.json",
			[   
				'query' => [
					'fields' => 'id,name,role',
					'access_token' => $access_token
				]
			]
		);
		
		$get_res_1 = json_decode($response_1->getBody()->getContents(), true);

		$theme_id = "";

		foreach($get_res_1['themes'] as $r) {
			if($r['role'] == "main") {
				 $theme_id = $r['id'];
			}
		}
	
	$response_script  = $client->request(
						'DELETE', 
						"https://{$store}/admin/themes/{$theme_id}/assets.json",
						[   
							'query' => [
								'asset[key]'=>'templates/page.quiz-form.liquid',
								'access_token' => $access_token
							]
						]
					);
			
	$results = json_decode($response_script->getBody()->getContents(), true);		
	
	
		//code for custom collection start
     $response = $client->request(
		'GET', 
		"https://{$store}/admin/custom_collections.json",
		[   
			'query' => [
				'fields' => 'id,images,title,vendor,variants',
				'access_token' => $access_token
			]
		]
	);

	$get_res = json_decode($response->getBody()->getContents(), true);

	
	$res_title = array();
	foreach($get_res['custom_collections'] as $r){
		$res_id = $r['id'];
		$res_title[$res_id] = $r['title'];
	}
	foreach($res_title as $key=>$val){
			if ("Quiz Products" == $val){
				 $response = $client->request(
					   'DELETE', 
						   'https://'.$store.'/admin/custom_collections/'.$key.'.json',
						   [   
							   'query' => [
								   'access_token' => $access_token
							   ]
						   ]
				   );	
	
			
				$get_res_webhook  = json_decode($response->getBody()->getContents(), true);
			}
		
	}
	/////////////////////////////		

$del= "Delete from `installs` WHERE store='".$store."'";
$delete = $db->query($del);