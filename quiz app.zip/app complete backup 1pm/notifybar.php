<?php

include('config.php');

require 'vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();
$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
$nstore = $_GET['shop'];
//$nstore="test-lens.myshopify.com";
$store = $nstore; 
$select = $db->query("SELECT access_token,id FROM installs WHERE store = '$store'");

$user = $select->fetch_object();
$access_token = $user->access_token;
$store_access_id = $user->id;
$client = new Client();
    $response_webhook  = $client->request(
		'GET', 
		"https://{$store}/admin/script_tags.json",
		[   
			'query' => [
				'fields' => 'id,src',
				'access_token' => $access_token
			]
		]
	);

	$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
	$res_title_webhook = array();
 	foreach($get_res_webhook['script_tags'] as $r){
		$script_id = $r['id'];
		$res_title_webhook[$script_id] = $r['src'];
 	}
	
///////////////////////////////
	
	
	
$sql_setting = "SELECT * FROM app_check WHERE store_url='".$store."'";
	$value_api = $con->query($sql_setting);
	if ($value_api->num_rows > 0) {
    // output data of each row     
		foreach($value_api as $Vot_api) {
			$shop_status_api= $Vot_api['period']; 
			$shop_status= $Vot_api['status']; 
			$shop_end_date= $Vot_api['end_date'];  
		}
	}
	$today= date_create(date("Y-m-d"));
	if($shop_status_api=='trial' && $shop_end_date == $today){
		$auth_user= 'expire';
	}else{
		$auth_user='validate';
	}
	$auth_user="";	
	$int= date_create($shop_end_date);
	$diff=date_diff($int,$today);
	$daysLeft = $diff->format("%a");
	if($shop_status == 0){
		if($daysLeft > 0){
			$results_ex='<div class="top-bar grid--full stickyNotifctn">
				<div class="grid__item">
					<a href="javascript:void(0)" class="topCloseLayer">X</a>
					<span style="color: #fff;font-size: 14px;font-weight: bold;">Your trial period will be expire in '.$daysLeft.'&nbsp;days</span>
				</div>
				</div>';	
	 	}else{
	$res_title_webhook = array();
 	foreach($get_res_webhook['script_tags'] as $r){
		$res_title_webhook[] = $r['src'];
 	}
			if (in_array("https://kbizsoft.com/dev/app/quiz_shopify/assets/js/trail.js", $res_title_webhook)){}
			
			else{		
				  $script_tag_ajax = [
						'script_tag' => [
						   'src' => 'https://kbizsoft.com/dev/app/quiz_shopify/assets/js/trail.js', 
						   'event' => 'onload'      
						   ] ];
				$response_script = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
					'json'    => $script_tag_ajax,
					'headers' => ['X-Shopify-Access-Token' => $access_token]
				]);
					$result_script = json_decode($response_script->getBody()->getContents(), true);
			
			}
			$auth_user = 'expire';
			$results_ex='<div class="top-bar grid--full stickyNotifctn">
				<div class="grid__item">
					<a href="javascript:void(0)" class="topCloseLayer">X</a>
					<span style="color: #fff;font-size: 14px;font-weight: bold;">Your Trial period has expire please upgrade</span>
				</div>
				</div>';
			?>
			<style>
			.trailQuestion{
				display:none;
			  }
			</style>
			<?php
		}
	}elseif($shop_status == 1 AND $daysLeft == 0 ){
	//	$auth_user = 'expire';
		require_once('vendor/autoload.php');
		require_once('stripe-pay/init.php');
		$stripe = array(
		  "secret_key"      => "sk_test_NMq1VxAaD1opQ2RkozLE0oyh",
		  "publishable_key" => "pk_test_iFUDaRmSMQYQdtunRHzsrADa"
		);
		\Stripe\Stripe::setApiKey('sk_test_NMq1VxAaD1opQ2RkozLE0oyh');

		require_once('stripe-pay/lib/Customer.php');
		
		 $getStore=$_GET['shop'];
		
		 $sql = "select * FROM payments WHERE store_url = '".$getStore."' order by id desc";
		$value_result = $con->query($sql);
		$cust_id = $value_result->fetch_object();
		 $custmer_id = $cust_id->itemid;
		if($custmer_id){
			$cu = \Stripe\Customer::retrieve($custmer_id);
			$result_end = $cu->subscriptions->data['0']->current_period_end;
			$status = $cu->subscriptions->data['0']->status;
			$end_date = date('Y-m-d', $result_end);
			if($status == "active"){
				$sql_update_api = "UPDATE app_check set status ='1',end_date = '".$end_date."' where store_url ='".$getStore."'"; 
				$sq_update = $con->query($sql_update_api); 
			}else{
				$auth_user = 'expire';
				$res_title_webhook = array();
				foreach($get_res_webhook['script_tags'] as $r){
					$res_title_webhook[] = $r['src'];
				}
					if (in_array("https://kbizsoft.com/dev/app/quiz_shopify/assets/js/trail.js", $res_title_webhook)){}
					
					else{		
						  $script_tag_ajax = [
								'script_tag' => [
								   'src' => 'https://kbizsoft.com/dev/app/quiz_shopify/assets/js/trail.js', 
								   'event' => 'onload'      
								   ] ];
						$response_script = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
							'json'    => $script_tag_ajax,
							'headers' => ['X-Shopify-Access-Token' => $access_token]
						]);
							$result_script = json_decode($response_script->getBody()->getContents(), true);
					
					}
					$auth_user = 'expire';
					$results_ex='<div class="top-bar grid--full stickyNotifctn">
						<div class="grid__item">
							<a href="javascript:void(0)" class="topCloseLayer">X</a>
							<span style="color: #fff;font-size: 14px;font-weight: bold;">Your Trial period has expire please upgrade</span>
						</div>
						</div>';
			}
		}
	}else{
		foreach($res_title_webhook as $key=>$val){
			
			if ("https://kbizsoft.com/dev/app/quiz_shopify/assets/js/trail.js" == $val){
				
					$response_webhook  = $client->request(
						'DELETE', 
						"https://{$store}/admin/script_tags/{$key}.json",
						[   
							'query' => [
								'fields' => 'id,src',
								'access_token' => $access_token
							]
						]
					);
			
				$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
			}
		}
		
	}
	
	
 ?>