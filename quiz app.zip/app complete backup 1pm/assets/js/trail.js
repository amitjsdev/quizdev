//var element = document.getElementById("quiztrailperiod");
//  document.getElementById("quiztrailperiod").innerHTML = "";
 // alert("asds");
 
// Get the modal
var modal = document.getElementById('myModal');
//alert(modal);
modal.style.display = "block";