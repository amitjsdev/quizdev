      $(function () {
        $('form').on('submit', function (e) {
			var shopUrls = $('.shopUrls').val();
		  e.preventDefault();
				var isFormValid = true;
				$("input.requiredFields").each(function(){
					if ($.trim($(this).val()).length == 0){
						isFormValid = false;
					}
				});
				var parentClass = $(this).parent().prop('className');
				var dataType = $('.submitBtn').parent().attr('data-type');
				var dataId = $('.submitBtn').parent().attr('data-id');
				var dataClass = $(this).parent().attr('data-class');
				if(dataType == "CheckBox"){
					
					$("input:checkbox.CheckedBoxVal"+dataId).each(function(index){
						
						var name = $(this).attr("name");
						 var fields = $("input:checkbox.CheckedBoxVal"+dataId).serializeArray(); 
						if (fields.length === 0) 
						{ 
							isFormValid = false;
						}
					}); 
					
				}
				
				if(dataType == "Radio"){
					$("input:hidden.radioCheckedVal"+dataId).each(function(event){
							var name = $(this).attr("name");
									if($("input:hidden[name="+name+"]").val() == ""){
								isFormValid = false;
							}  
						});
				}
				if (!isFormValid){
					$('.requiredErros').html("");
					$('.requiredErros').append('Please fill the required fields.');
					//alert("Please fill the required fields");
					return isFormValid;
				}else{
					$('.loader').css('display','block');
					$('.form-bg').css('opacity','.5'); 
					var rad = [];
					var v= $('input[type=radio].requiredFields:checked');
					$(v).each(function(i){
					rad.push($(this).attr('id'));

					});
					
					var chk = [];
					var d= $('input[type=checkbox].requiredFields:checked');
					$(d).each(function(n){
					chk.push($(this).attr('id'));
					});
					
					rad.push.apply(rad, chk);
					localStorage.setItem('todoData', rad);
					 var stats = localStorage.getItem('todoData');
					  stats = stats.replace(/,/g, "+");
					
					var url ="https://"+shopUrls+"/collections/quiz-products";
					 var lasturl=url+'/'+stats;
					  var str = lasturl.replace(/\s+/g, '');
					  localStorage.setItem('finalurl', str);
					   var finalurl = localStorage.getItem('finalurl');

					if(finalurl){
							$.ajax({
									type: 'post',
									url: 'https://kbizsoft.com/dev/app/quiz_shopify/quiz_save.php',
									data: $('form').serialize(),
									success: function (data) {
										   console.log(data);
										   //alert(data);
										  window.location.href = finalurl;
									}
						});

					}
				}
        });

    });
	  

			
	  
	 $(document).ready(function(){
	var shopUrls = $('.shopUrls').val();
	$.get("https://kbizsoft.com/dev/app/quiz_shopify/json_send.php?shop="+shopUrls, function(data, status){
		var object = jQuery.parseJSON(data);
			var rad = 1;
			var count = object.length;
				 $.each(object, function( index, value ){
					 var ansId = value['id'];
					 var ques_type = value['ques_type'];
					 var ques_title = value['ques_title'];
					 var cat_ans = value['cat_ans'];
					 var cat_ans_tag = value['cat_ans_tag'];
					 var cat_id = value['cat_id'];
					 var store_access_id = value['store_access_id'];
					 $('.questionData').append('<input type="hidden" name="store_access_id"  value="'+ store_access_id +'">');
					 //radio questions
					if(ques_type == "Radio"){
						var att_radio = $('.radioSetup'+cat_id).attr('data-radio'+cat_id);
						if(att_radio != cat_id){
							$('.questionData').append('<div  data-radio'+cat_id+'="'+cat_id+'" class="setup-content radioSetup'+cat_id+'" id="step-'+rad+'"><h3>'+ques_title+'</h3><div data-class="radioCheckedVal'+cat_id+'" data-id="'+cat_id+'" data-type="Radio" class="checkbox_row"><input  type="hidden" name="radio_ques['+cat_id+']" value="'+cat_id+'"><input type="hidden" name="rad_data'+cat_id+'" value="" class="radioCheckedVal'+cat_id+'"><button class="btn prevBtn pull-left" type="button" ><i class="fa fa-chevron-left"></i></button><button class="btn nextBtn pull-right" data-button="radioNxt" data-radValid="'+cat_id+'" type="button" ><i class="fa fa-chevron-right"></i></button><div  class="optionLayout radioBox'+cat_id+'"></div></div>');
							
							$('.progressBar').append('<div class="stepwizard-step progressColor'+rad+'"><a href="#step-'+rad+'" type="button" class="btn btn-default btn-circle" disabled="disabled">'+rad+'</a></div>'); 
							rad = rad + 1;
						}
						$('.radioBox'+cat_id).append('<div class="ck-button"><label class="quesCatId" id="'+cat_id+'"><input class="requiredFields" type="radio" name="data['+cat_id+']" id="'+cat_ans_tag+'" value="'+cat_ans+'"><span>'+cat_ans+'</span></label></div>');
						
					}
					//checkBox questions
					if(ques_type == "CheckBox"){
						var att_checkbox = $('.chekSetup'+cat_id).attr('data-checkbox'+cat_id);
						if(att_checkbox != cat_id){
							$('.questionData').append('<div data-class="CheckedBoxVal'+cat_id+'" data-id="'+cat_id+'" data-type="CheckBox" data-checkbox'+cat_id+'="'+cat_id+'" class="setup-content chekSetup'+cat_id+'" id="step-'+rad+'"><input  type="hidden" name="checkbox_ques[]" value="'+cat_id+'"> <h3>'+ques_title+'</h3><div class="checkbox_row"></div><button class="btn prevBtn pull-left" type="button" ><i class="fa fa-chevron-left"></i></button><button class="btn nextBtn pull-right " data-button="CheckBoxNxt" data-radValid="'+cat_id+'" type="button" ><i class="fa fa-chevron-right"></i></button><div  class="optionLayout checkbox'+cat_id+'"></div></div>');
							
							$('.progressBar').append('<div class="stepwizard-step progressColor'+rad+'"><a href="#step-'+rad+'" type="button" class="btn btn-default btn-circle" disabled="disabled">'+rad+'</a></div>'); 
							rad = rad + 1;
						}
						$('.checkbox'+cat_id).append('<div class="ck-button"><label><input  type="hidden" name="checkbox_ques_ans[]" value="'+cat_id+'"><input class="requiredFields CheckedBoxVal'+cat_id+'" id="'+cat_ans_tag+'" type="checkbox" name="checkbox_val[]" value="'+ansId+'"><span>'+cat_ans+'</span></label></div>');
					}
					//Text questions
					if(ques_type == "Text"){
						$('.questionData').append('<div data-type="Text" class="setup-content" id="step-'+rad+'"><h3>'+ques_title+'</h3><div class="checkbox_row"><input  type="hidden" name="text_ques[]" value="'+cat_id+'"><input type="text" class="requiredFields typeText textVal'+cat_id+'" name="field_val[]"></div><button class="btn prevBtn pull-left" type="button" ><i class="fa fa-chevron-left"></i></button><button class="btn nextBtn pull-right " type="button" data-button="textNxt" data-radValid="'+cat_id+'"><i class="fa fa-chevron-right"></i></button></div>');
						
						$('.progressBar').append('<div class="stepwizard-step progressColor'+rad+'"><a href="#step-'+rad+'" type="button" class="btn btn-default btn-circle" disabled="disabled">'+rad+'</a></div>'); 
						rad = rad + 1;
					}
					 if (!--count) doMyThing();
				}); 
				
			}); 
			//after loop ended code
			function doMyThing(){
				var navListItems = $('div.setup-panel div a'),
				allWells = $('.setup-content'),
				allNextBtn = $('.nextBtn'),
				allPrevBtn = $('.prevBtn');
				allWells.hide();
				navListItems.click(function (e) {
					//return false;
					//alert("dfdf");
					e.preventDefault();
					var $target = $($(this).attr('href')),
					$item = $(this);

					if (!$item.hasClass('disabled')) {
						navListItems.removeClass('btn-primary').addClass('btn-primary');
						$item.addClass('btn-primary');
						allWells.hide();
						$target.show();
						$target.find('input:eq(0)').focus();
					}
				});

				allPrevBtn.click(function(){
					var curStep = $(this).closest(".setup-content"),
					curStepBtn = curStep.attr("id"),
					prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");
					prevStepWizard.removeAttr('disabled').trigger('click');
				});

				allNextBtn.click(function(){
					var  radValid = $(this).attr('data-radValid');
					var  radbttn = $(this).attr('data-button');
					var radiocheck = true;
					var checkBox = true;
					var textVal = true;
					//alert(radValid);
					//validation radio
					if(radbttn == "radioNxt"){
						$("input:hidden.radioCheckedVal"+radValid).each(function(event){
							var name = $(this).attr("name");
									if($("input:hidden[name="+name+"]").val() == ""){
									//alert("asds");
									radiocheck = false;
								}  
						});
						if(radiocheck){
									$('.requiredErros').html("");
									var curStep = $(this).closest(".setup-content"),
									curStepBtn = curStep.attr("id"),
									nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
									curInputs = curStep.find("input[type='text'],input[type='url']"),
									isValid = true;

									$(".form-group").removeClass("has-error");
										for(var i=0; i<curInputs.length; i++){
										if (!curInputs[i].validity.valid){
											isValid = false;
											$(curInputs[i]).closest(".form-group").addClass("has-error");
										}
									}
									if (isValid)
										nextStepWizard.removeAttr('disabled').trigger('click');
						}else{
							$('.requiredErros').html("");
							$('.requiredErros').append('Please select one option in each question.');
							return false;
						}
					}
					//validation checkbox
					if(radbttn == "CheckBoxNxt"){
					$("input:checkbox.CheckedBoxVal"+radValid).each(function(index){
						
						var name = $(this).attr("name");
						 var fields = $("input:checkbox.CheckedBoxVal"+radValid).serializeArray(); 
						if (fields.length === 0) 
						{ 
							checkBox = false;
						}
					}); 
						if(checkBox){
							$('.requiredErros').html("");
							var curStep = $(this).closest(".setup-content"),
							curStepBtn = curStep.attr("id"),
							nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
							curInputs = curStep.find("input[type='text'],input[type='url']"),
							isValid = true;

							$(".form-group").removeClass("has-error");
								for(var i=0; i<curInputs.length; i++){
								if (!curInputs[i].validity.valid){
									isValid = false;
									$(curInputs[i]).closest(".form-group").addClass("has-error");
								}
							}
							if (isValid)
								nextStepWizard.removeAttr('disabled').trigger('click');
						}else{
							$('.requiredErros').html("");
							$('.requiredErros').append('Please select one option in each question.');
							return false;
						}
					}
					//validation text
					if(radbttn == "textNxt"){
						var nameVal = $("input:text.textVal"+radValid).val();
							if(nameVal.length == 0){
								textVal = false;
							} 
						if(textVal){
							$('.requiredErros').html("");
							var curStep = $(this).closest(".setup-content"),
							curStepBtn = curStep.attr("id"),
							nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
							curInputs = curStep.find("input[type='text'],input[type='url']"),
							isValid = true;

							$(".form-group").removeClass("has-error");
								for(var i=0; i<curInputs.length; i++){
								if (!curInputs[i].validity.valid){
									isValid = false;
									$(curInputs[i]).closest(".form-group").addClass("has-error");
								}
							}

							if (isValid)
								nextStepWizard.removeAttr('disabled').trigger('click');
						}else{
							$('.requiredErros').html("");
							$('.requiredErros').append('Field is required');
							return false;
						}
					}
				});
				$('div.setup-panel div a.btn-primary').trigger('click');
				$(".progressColor1 a").removeAttr('disabled');
				$( ".questionData .nextBtn.pull-right:last" ).addClass( "lastNextBtn" );
				$('.lastNextBtn').replaceWith('<button class="btn submitBtn pull-right" type="submit">Submit</button>');
			}
			//on form submit

			
			$(document).on('click','.quesCatId', function(){
			
				var id= $(this).attr("id");
				$('.radioCheckedVal'+id).val(1);
					
			}); 
	});