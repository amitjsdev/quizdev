<?php header('Access-Control-Allow-Origin: *'); 
	include('config.php');
 /* echo "<pre>";
print_r($_POST); */  
//date_default_timezone_set("America/Indiana/Indianapolis");

if($_POST)
{
	
		$store_access_id=$_POST['store_access_id'];
		if($_POST['checkbox_ques']){
			$checkbox_val=$_POST['checkbox_val'];
				$user_id=$_POST['user_id'];
				$checkbox_ques=$_POST['checkbox_ques'];
			/* 	echo "<pre>";
				print_r($checkbox_ques);  */
				foreach ($checkbox_val as $key=>$val_checkbox) {
				
					$sql_check="select cat_id,cat_ans from categories_ans where id ='".$val_checkbox."'";
					$result_chk=mysqli_query($con,$sql_check);
					$row=mysqli_fetch_assoc($result_chk);
						 $ques_id=$row['cat_id'];
						 $cat_ans=$row['cat_ans'];
						 $ans1="insert into quiz_ans(answers,question_id,user_id,store_access_id)values('".$cat_ans."','".$ques_id."','$user_id','$store_access_id')";	
						$reslt=mysqli_query($con,$ans1);
				
				}	
		} 
		 
		if($_POST['radio_ques']){
			//$count_id=$_POST['count_idr'];
			$user_id=$_POST['user_id'];
			$question1=$_POST['radio_ques'];
			$ans_radio=$_POST['data'];	
			
			foreach($ans_radio as $key=>$value) {					
				//if($question1[$key]){
					$ans2="insert into quiz_ans(answers,question_id,user_id,store_access_id)values('".$ans_radio[$key]."','".$question1[$key]."','$user_id','$store_access_id')";	
					$reslt=mysqli_query($con,$ans2);					 
				
				//}	    
			}
		}
		if($_POST['text_ques']){
			$user_id=$_POST['user_id'];
			$question=$_POST['text_ques'];
			$field_ans=$_POST['field_val'];
			foreach($question as $key=>$value){
				//if($question[$key]){
						$ans3="insert into quiz_ans(answers,question_id,user_id,store_access_id)values('".$field_ans[$key]."','".$question[$key]."','$user_id','$store_access_id')";	
						$reslt=mysqli_query($con,$ans3);
				//}
			}
		}	
}
	?>
