<?php include('config.php');
error_reporting(E_ALL & ~E_NOTICE);
/*--------------------Delete query for questions with answer start -------------------*/
if($_GET['cat_id'] != ""){
		$cat_id=$_GET['cat_id'];
		$ans_sql = "DELETE FROM categories_ans WHERE cat_id ='".$cat_id."'";
		$ans_resul=mysqli_query($con,$ans_sql);
		$cat_result = "DELETE FROM ques_categories WHERE id ='".$cat_id."'";			
		$cat_id_resul=mysqli_query($con,$cat_result);
		if($cat_id_resul){
			//echo $cat_id_resul;
			echo "<script type='text/javascript'>alert('Question Deleted successfully!');</script>";
		}  
   }
 
/*--------------------Delete query for questions with answer end -------------------*/  

$store = $_GET['shop'];
$select = $con->query("SELECT access_token,id FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
$store_access_id = $user->id;

   ?>
<html>
	<head>
	<link rel="stylesheet" href="assets/css/style.css">
		<script src="assets/js/field.jquery.js"></script>
	</head>
	<body>
<?php

include('notifybar.php');
echo $results_ex; 
?>
		<ul id="navi">
			<li><a class="menu" href="anavii.php?shop=<?php echo $store;?>">Add Question</a></li>
			<li><a  class="menu active" href="view_ques_list.php?shop=<?php echo $store;?>">View Question</a></li>
	    	<li><a  class="menu" href="user_ans_list.php?shop=<?php echo $store;?>">Users View</a></li>
			<li><a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Upgrade</a></li>
			<li><a  class="menu" href="stripe-pay/account_section.php?shop=<?php echo $store;?>">Account Details</a></li>
			<!--<li><a  class="menu" href="view-survey.php">View-Survey</a></li>-->
		</ul>	
		
		<div class="questionLists">
		<h1 class="headUpdate">List Of All Questions</h1>
            <div class="ui-card__section">
				<div class="ui-type-container">
                    <div class="table-wrapper">
					<?php 
					$sql="SELECT * FROM ques_categories WHERE store_access_id ='".$store_access_id."'";
					$result=mysqli_query($con,$sql);
					$row_count= $result->num_rows;
					if($row_count != 0){
					?>
						<table class="table_main">
							<thead>
								<tr class="trtop_gapiheading main_porduct_table">
								<th class="firstTh">Sr No.</th>
								<th class="secondTh">Question Type</th>
								<th class="thirdTh">Question</th>
								<th class="fourthTh">Action</th>
								</tr>
							</thead>
							 <tbody> 
							<?php
							$i=1;
							while($row=mysqli_fetch_assoc($result)){
							?>
								<tr class="tr_table">
									<td><?php echo $i;?></td>
									<td><?php echo $row['ques_type'];?></td>
									<td><?php echo $row['ques_title'];?></td>
									<td><a href="ques_edit.php?question_id=<?php echo $row['id'];?>&shop=<?php echo $store;?>">Edit</a> / <a class="deltText" href="view_ques_list.php?cat_id=<?php echo $row['id'];?>&shop=<?php echo $store;?>" Onclick="return ConfirmDelete();">Delete</a></td>
								</tr>

							<?php
							$i++;
							}
							?>
							</tbody>
						</table>
						<?php
					}else{
						?>
						<h2 class="emptyRecords" >No records found!</h2>
						<?php
					}
						?>
					</div>
				</div>
			</div>
		</div>
<div id="myModal" class="modal">
  <div class="modal-content">
   <!-- <span class="close">&times;</span>-->
    <p>Your trial period has expire. Please Upgrade Your Plan!</p>
	<a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Click Here</a>
  </div>

</div>		
<?php
if($auth_user == "expire"){
?>
<script>
// Get the modal
var modal = document.getElementById('myModal');
//alert(modal);
modal.style.display = "block";

</script>
		
<?php
}
?>		
<script>
function ConfirmDelete(){

  var x = confirm("Are you sure you want to delete this question ? If you delete this question the answers related to this question will also be deleted.");
  if (x)
      return true;
  else
    return false;
}
</script>
<?php include('notifyjs.php');?>

	</body>
</html>