<?php header('Access-Control-Allow-Origin: *'); 
include('config.php');
$store = $_GET['shop'];
$select = $con->query("SELECT access_token,id FROM installs WHERE store = '$store'");
$user = $select->fetch_object();
 $store_access_id = $user->id;

$arr=array();
/*join query for get data from two tabels */	
 $sql="SELECT * FROM ques_categories Left JOIN categories_ans ON ques_categories.id = categories_ans.cat_id AND ques_categories.store_access_id ='".$store_access_id."' AND categories_ans.store_access_id ='".$store_access_id."'";
$result=mysqli_query($con,$sql);
/* echo "<pre>";
print_r($result);
die; */
$fnary = array();
while($row=mysqli_fetch_assoc($result)){
	if($row['store_access_id']){
		$arr[] =$row;
		$cat_id = $row['cat_id'];
		$ques_type = $row['ques_type'];
		$ques_title[] = $row['ques_title'];
		$cat_ans[] = $row['cat_ans'];
	}
	//$fnary[$cat_id] = array('ques_title'=>$ques_title,'cat_ans'=>array($cat_ans));
} 

/* for($i=1; $i<count($cat_ans); $i++){
	//echo $cat_ans[$i];
	echo $ques_title[$i].'<br/>';
}
die; */
/* $sql="SELECT * FROM ques_categories";
	$result=mysqli_query($con,$sql);
	
	while($row=mysqli_fetch_assoc($result)){
		$ques_id=$row['id'];
		$arr=$row;
		echo $sql2="SELECT * FROM categories_ans where cat_id='".$ques_id."'";
		
		$result2=mysqli_query($con,$sql2);
		while($row2=mysqli_fetch_assoc($result2)){
			
			array_push($arr,['cat_ans' => $row2]);
		//$arr['ans'] =$row2;
		}
	}
 */

/* echo "<pre>";
 
print_r($arr);  */
 
echo json_encode($arr,true);										
?>
   
