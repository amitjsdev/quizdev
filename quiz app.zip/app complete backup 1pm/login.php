<?php
ob_start();

require 'vendor/autoload.php';

use Carbon\Carbon;

use GuzzleHttp\Client; 
$dotenv = new Dotenv\Dotenv(__DIR__);

$dotenv->load(); 
$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));  
$api_key = getenv('SHOPIFY_APIKEY');

$secret_key = getenv('SHOPIFY_SECRET'); 
$query = $_GET; 
/* echo "<pre>";
print_r($query); */
if (!isset($query['code'], $query['hmac'], $query['shop'], $query['timestamp'])) {

	exit;

} 
 $hmac = $query['hmac'];

unset($query['hmac']); 
$params = [];

foreach ($query as $key => $val) {

	$params[] = "$key=$val";

}  
asort($params);

$params = implode('&', $params);

$calculated_hmac = hash_hmac('sha256', $params, $secret_key); 
$store = $query['shop'];
//echo $hmac."cal ".$calculated_hmac;

if($hmac === $calculated_hmac){

    /* echo "ewreretrdtt";
	echo $hmac."cal ".$calculated_hmac;
	die; */

	$client = new Client(); 
	$response = $client->request(

		'POST', 

		"https://{$store}/admin/oauth/access_token",

		[

			'form_params' => [

				'client_id' => $api_key,

				'client_secret' => $secret_key,

				'code' => $query['code']

			]

		]

	); 
	$data = json_decode($response->getBody()->getContents(), true);
	//print_r($data);
//	echo "vvvvvvvvvvvvvvvvvvvvvv";
    $access_token = $data['access_token'];
   
   //echo "SELECT nonce FROM installs WHERE store = '$store'";
	$select_nonce = $db->query("SELECT nonce FROM installs WHERE store = '$store'");
	if($select_nonce->num_rows > 0) {
	    $get_res = $select_nonce->fetch_object();
        $nonce_val = $get_res->nonce;
	}

	  
  $nonce = $nonce_val; 
   //die;
   
	if ($select = $db->prepare("SELECT id FROM installs WHERE store = ? AND nonce = ?")) {

		$select->bind_param('ss', $store, $nonce);

		$select->execute();

		$select->bind_result($id);

		$select->fetch();

		$select->close(); 
		if ($id > 0) {
           // echo "UPDATE installs SET access_token = '$access_token' WHERE id = '$id'";
			$db->query("UPDATE installs SET access_token = '$access_token' WHERE id = '$id'");
			//die;

		}

	}

    $response_webhook  = $client->request(
		'GET', 
		"https://{$store}/admin/webhooks.json",
		[   
			'query' => [
				'fields' => 'id,topic',
				'access_token' => $access_token
			]
		]
	);

	$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
	
	$res_title_webhook = array();
 	foreach($get_res_webhook['webhooks'] as $r){
		$res_title_webhook[] = $r['topic'];
 	}
    
    if (in_array("app/uninstalled", $res_title_webhook)){}
	else{
		$arguments_webhook = [
	   'webhook' => [
		'topic' => 'app/uninstalled',
			   'address' => 'https://kbizsoft.com/dev/app/quiz_shopify/uninstalled.php' 
			   ]
		];
		$response_script_webhook = $client->request('POST', 'https://'.$store.'/admin/webhooks.json', [
		   'json'    => $arguments_webhook,
		   'headers' => ['X-Shopify-Access-Token' => $access_token]
		]);
	}
	//code end webhooks
	
	//code for custom collection start
     $response = $client->request(
		'GET', 
		"https://{$store}/admin/custom_collections.json",
		[   
			'query' => [
				'fields' => 'id,images,title,vendor,variants',
				'access_token' => $access_token
			]
		]
	);

	$get_res = json_decode($response->getBody()->getContents(), true);

	$res_title = array();
	foreach($get_res['custom_collections'] as $r){
		$res_title[] = $r['title'];
	}

	if (in_array("Quiz Products", $res_title)){}
	else{
		
		$arguments_collection = [
					'custom_collection' => [
						"title" =>"Quiz Products"
					]
				];
		$response_script_collection = $client-> request('POST', 'https://'.$store.'/admin/custom_collections.json', [
			'json'    => $arguments_collection,
			'headers' => ['X-Shopify-Access-Token' => $access_token]
		]);
	}
	
	
		$response_1 = $client->request(
		'GET', 
		"https://{$store}/admin/themes.json",
			[   
				'query' => [
					'fields' => 'id,name,role',
					'access_token' => $access_token
				]
			]
		);
		
		$get_res_1 = json_decode($response_1->getBody()->getContents(), true);

		$theme_id = "";

		foreach($get_res_1['themes'] as $r) {
			if($r['role'] == "main") {
				 $theme_id = $r['id'];
			}
		}
	
		$result=' {% if customer  %}
			  {% else %}
			<script>
			  window.location.href = "/account/login";
			</script>
			  {% endif %}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://kbizsoft.com/dev/app/quiz_shopify/assets/css/custom.css">
	<div class="form-bg">
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 width-50">
      <div class="logos logo-left">
        <img src="https://kbizsoft.com/dev/app/quiz_shopify/assets/img/wellness.png" class="img-responsive" alt="LOGO">
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 width-50">
      <div class="logos logo-right">
        <img src="https://kbizsoft.com/dev/app/quiz_shopify/assets/img/anavii.png" class="img-responsive" alt="LOGO">
      </div>
    </div>
  </div>
        <div class="requiredErros">
      </div>
    <input type="hidden" class="shopUrls" value="{{ shop.permanent_domain }}">
   <form class="multistepForm questionData" method="post">
    <input type="hidden" name="user_id"  value="{{customer.id}}">
	</form>
  <div class="stepwizard">
    <div class="stepwizard-row setup-panel progressBar">
	<span style="display:none" class="">
	    <div class="stepwizard-step">
        <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
      </div>
	</span>
    </div>
  </div>	
  <p class="breif_note">THESE STATEMENTS AND PRODUCTS HAVE NOT BEEN EVALUATED BY THE FDA. THESE PRODUCTS ARE NOT INTENDED TO DIADNOSE, TREAT OR CURE ANY DISEASE. PLEASE CONSULT YOUR PHYSICIAN IF YOU ARE TAKING MEDICATION.</p>
</div>
<div style="position:absolute;top:30%;left:50%;" class="loader"></div>
<div id="myModal" class="modal">
  <div class="modal-content">
    <p>Trial period has expire.</p>
  </div>
</div>	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://kbizsoft.com/dev/app/quiz_shopify/assets/js/getQuestion.js"></script>';
		
		//script for add new template
$arguments =  array(
               'asset' => [
					'key' => 'templates/page.quiz-form.liquid',
					'value' => $result
					//'access_token' => $access_token
					]
				);
$response_script = $client->request('PUT', 'https://'.$store.'/admin/themes/'.$theme_id.'/assets.json', [
'json'    => $arguments,
'headers' => ['X-Shopify-Access-Token' => $access_token]
]); 

$results = json_decode($response_script->getBody()->getContents(), true);	

//add collection template
	$img_src = "{{ product.featured_image.src | product_img_url: 'medium' }}";
	
$result_collection ='<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://kbizsoft.com/dev/app/quiz_shopify/assets/css/custom.css">
<div class="form-bg">
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 width-50">
      <div class="logos logo-left">
        <img src="https://kbizsoft.com/dev/app/quiz_shopify/assets/img/wellness.png" class="img-responsive" alt="LOGO">
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 width-50">
      <div class="logos logo-right">
        <img src="https://kbizsoft.com/dev/app/quiz_shopify/assets/img/anavii.png" class="img-responsive" alt="LOGO">
      </div>
    </div>
  </div>
  <div class="main-bg">	
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-6 top-logo mt-2 leftPrdct">
            <p class="anavill pclass">Anavill Market Wellness PAL recommends:</p>
            <div class="row">
              <div class="col-md-12 one-colm tctcntr">
			  {% assign j = 0 %}
                {% for product in collection.products %}
                {% if j <= 1 %}
                <div class="col-md-6 jf">
                  <div class="prdctBorder">
                    <img class="productsImg" src="'.$img_src.'"> 
                    <div class="form-group mt-4">
                      <form action="/cart/add" method="POST">
					   <input type="hidden" name="id" value="{{ product.variants.first.id }}" />
                        <button class="add-button" type="submit">Add to Cart!</button>
                      </form>
                      <br>
                    <a href="{{ product.url }}" class="learnMoreBtn">Learn More</a>
                      </form>
                    </div>
                  </div>
                </div>	
                 {% assign j = j | plus: 1 %}
              {% endif %}
				{% endfor %}
			{% if j == 0%}
			 <button class="noProductBtn">No Matching Products Found!</button>
			{% endif %}
              </div>
            </div>	
          </div>
<div class="bdr">
              </div>
          <div class="col-md-6 text-right mt-2 rightPrdct">
            <p class="also text-center">Also for you:</p>
            <div class="main-2 text-center">
              <div class="row">
                <div class="col-md-12 second-colm">
				{% assign p = 0 %}
				{% if j == 0 or j == 1%}
				{% if collections.quiz-products.products.size > 0 %}
					<div class="prdctBorder singlePrdct">
					{% for product in collections.quiz-products.products %}
					{% if p == 0 %}
					<img class="productsImgSingle"src="'.$img_src.'">
                      <div class="form-group mt-4">
                      <form action="/cart/add" method="POST">
					   <input type="hidden" name="id" value="{{ product.variants.first.id }}" />
                        <button class="add-button" type="submit">Add to Cart!</button>
                      </form>
                      <br>
						<a href="{{ product.url }}" class="learnMoreBtn">Learn More</a>
                    </div>
					{% assign p = p | plus: 1 %}
					{% endif %}
				{% endfor %}
				</div>
				{% endif %}
				{% else %}
					{% assign b = 0 %}
					{% assign y = 0 %}
					{% assign z = 0 %}
					{% for product in collection.products %}
					{% if b == 2 %}
					<div class="prdctBorder singlePrdct">
                     <img class="productsImgSingle"src="'.$img_src.'">
                      <div class="form-group mt-4">
                      <form action="/cart/add" method="POST">
					   <input type="hidden" name="id" value="{{ product.variants.first.id }}" />
                        <button class="add-button" type="submit">Add to Cart!</button>
                      </form>
                      <br>
						<a href="{{ product.url }}" class="learnMoreBtn">Learn More</a>
                    </div>
					{% assign z = z | plus: 1 %}
					</div>
					{% endif %}					 
					{% assign b = b | plus: 1 %}                 
				{% endfor %}
				{% endif %}
				{% if z == 0 %}
				{% if collections.quiz-products.products.size > 0 %}
					{% for product in collections.quiz-products.products %}				
					{% if y == 0 %}
					<div class="prdctBorder singlePrdct">
					<img class="productsImgSingle"src="'.$img_src.'">
                      <div class="form-group mt-4">
                      <form action="/cart/add" method="POST">
					   <input type="hidden" name="id" value="{{ product.variants.first.id }}" />
                        <button class="add-button" type="submit">Add to Cart!</button>
                      </form>
                      <br>
						<a href="{{ product.url }}" class="learnMoreBtn">Learn More</a>
                    </div>
					{% assign y = y | plus: 1 %}
						</div>
					{% endif %}
				{% endfor %}		
				{% else %}	
				<style>
				.singlePrdct{
					display:;
				}
				</style>
				<button class="noProductBtn">Not Available!</button>				
				{% endif %}
				{% endif %}				
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>		
    <footer class="footerDiv">
      <div class="container-fluid">
        <div class="row">
        </div>
      </div>
    </footer>
  </div>
   <p class="txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book. <p>   
</div>';
$arguments =  array(
               'asset' => [
					'key' => 'templates/collection.QuizProducts.liquid',
					'value' => $result_collection
					//'access_token' => $access_token
					]
				);
$response_script = $client->request('PUT', 'https://'.$store.'/admin/themes/'.$theme_id.'/assets.json', [
'json'    => $arguments,
'headers' => ['X-Shopify-Access-Token' => $access_token]
]); 

$results_collection = json_decode($response_script->getBody()->getContents(), true);






	$getStore= $_GET['shop'];

		$today=  date("Y-m-d");
		$next= date("Y-m-d",strtotime('+14 days', strtotime($today)));
		
	$select_nonce = $db->query("SELECT * FROM app_check WHERE store_url = '$getStore'");
	if($select_nonce->num_rows > 0) {
		$sql_update_api = "UPDATE app_check set start_date ='".$today."',end_date = '".$next."' where store_url ='".$getStore."'"; 
				$sq_update = $db->query($sql_update_api); 
	}else{

		$sql_insert_api = "INSERT INTO app_check(store_url,status,period,start_date,end_date) VALUES ('".$getStore."','0','trial','".$today."','".$next."')";  
		$sq_ins = $db->query($sql_insert_api); 
	}	
	 echo "<script>window.location = 'https://".$getStore."/admin/apps/quiz-kbiz-app?shop=".$getStore."'</script>";	
}



ob_end_flush();
exit;
