<?php
//session_start();
//header('Access-Control-Allow-Origin: *');
//error_reporting(E_ALL);
//ini_set('display_errors', '0');


include('config.php');

include('notifybar.php');
?>
 <!DOCTYPE html> 
 <html lang="en">
      <head>
      <meta charset="utf-8" /> 
	<link rel="stylesheet" href="assets/css/style.css">
		<script src="assets/js/field.jquery.js"></script>
		</head>
		<body>
	<?php echo $results_ex; ?>
	
<div class="trailQuestion">
		<ul id="navi">
			<li><a class="menu active" href="anavii.php?shop=<?php echo $store;?>">Add Question</a></li>
			<li><a  class="menu" href="view_ques_list.php?shop=<?php echo $store;?>">View Question</a></li>
			<li><a  class="menu" href="user_ans_list.php?shop=<?php echo $store;?>">Users View</a></li>
			<li><a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Upgrade</a></li>
			<li><a  class="menu" href="stripe-pay/account_section.php?shop=<?php echo $store;?>">Account Details</a></li>
		</ul>		
			<div class="container">
			<h1 class="headUpdate">Add new Questions</h1>
				<form method="post" enctype="multipart/form-data">
					<div class="choose_ques">
						<label class="question-type">Question Type:</label>
						<select class="form-control" name="ques_type" id="sel1" required>
							<option value="">Select Question Type</option>
							<option class="text1" value="Text">Text</option>
							<option class="radio2" value="Radio">Radio Buttons</option>
							<option class="checkbox3" value="CheckBox">CheckBox</option>
						</select>
					</div>
					<div class="qust_page">
						<div class="col-25">
							<label>Write Your Question</label>
						</div>
						<textarea class="txt-res" name="ques_title" required></textarea><br><br>
						<div class="row text">
							<div class="col-25">
								<label>Options: </label>
							</div>
							<div class="col-75">
								<div class="col-md-9 input_fields_container optionsDiv">
									<div class="optionfields">
									<label class="formLabels">
										Label<br>
										<input class="field_label_form" id="label_add_more" type="text"  name="label_val[]">
										
									</label>
									<label class="formLabels">
										Value
										<input class="field_label_form" id="required_add_more" type="text" name="field_val[]">
									</label>
										<button class="btn btn-sm btn-primary add_more_button" style="cursor: pointer;">Add More Fields</button>
									</div>
								</div>
							</div>
						</div>
						<input type="submit" class="btn" value="Submit" name="submit">
					</div>
				</form>	  
			</div>
		</div>
		

<!-- Trigger/Open The Modal 
<button id="myBtn">Open Modal</button>-->
<div id="myModal" class="modal">
  <div class="modal-content">
   <!-- <span class="close">&times;</span>-->
    <p>Your trial period has expire. Please Upgrade Your Plan!</p>
	<a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Click Here</a>
  </div>

</div>

<?php

if($auth_user == "expire"){
?>
<script>
// Get the modal
var modal = document.getElementById('myModal');
//alert(modal);
modal.style.display = "block";

</script>
		
<?php
}
			
//////////////
	if(isset($_POST['submit'])){
		$cat_id=$_POST['ques_type'];
		if($cat_id){
			$ques_type=$_POST['ques_type'];
			$ques_title=$_POST['ques_title'];
			$ques_ty="insert into ques_categories(ques_type,ques_title,store_access_id)values('$ques_type','$ques_title','$store_access_id')";	
			$reslt1=mysqli_query($con,$ques_ty);
			$ques_table_id=$con->insert_id;
			if($ques_table_id){ 
				if($_POST['label_val']){
					$field_val_tags=$_POST['field_val'];
					$field_ans=$_POST['label_val'];
					foreach ($field_ans as $key=>$val) {
						$field_val_tag=strtolower($field_val_tags[$key]);
						$field_val_tag=str_replace(' ', '_', $field_val_tag);
						if($val != '' OR $field_val_tag != "" ){
							$ans="insert into categories_ans(cat_ans,cat_ans_tag,cat_id,store_access_id)values('".$field_ans[$key]."','".$field_val_tag."','".$ques_table_id."','".$store_access_id."')";	
							$reslt=mysqli_query($con,$ans);
						}                          
					}
					
				} 
				if($ques_type == "Text"){
					$ans="insert into categories_ans(cat_ans,cat_ans_tag,cat_id,store_access_id)values('text','text','".$ques_table_id."','".$store_access_id."')";	
					$reslt=mysqli_query($con,$ans);	
				}
			} 
			if($reslt != "" OR $reslt1 != ""){
				echo "<script>alert('Form Submitted successfully!');</script>";
			}
		}
	}

	?>
<script>
	$(document).ready(function() {
		var max_fields_limit      = 10; //maximum input boxes allowed

		var x = 1; //initlal text box count
		$('.add_more_button').click(function(e){ //on add input button click
			e.preventDefault();
			if(x < max_fields_limit){ //max input box allowed
				x++; //text box increment
				$('.input_fields_container').append('<div class="xtra"><input class="field_label_more" id="required_remove_label" type="text" name="label_val[]" required><input type="text" class="field_label_more val_class" id="required_remove" name="field_val[]" required /><a class="remove_field" style="margin-left:10px; cursor: pointer; ">Remove</a></div>'); //add input box
			}
		});
		$('.input_fields_container').on("click",".remove_field", function(e){
			var x = confirm("Are you sure you want to delete?");
			if (x){
				e.preventDefault(); $(this).parent('div').remove(); x--;
				$("#required_remove").prop('required',false);
				$("#required_remove_label").prop('required',false);
				return true;
			}else{
				return false;
			}  
		}); 
	});
</script>						
<script type="text/javascript">
	jQuery(document).ready(function(){
		$("select#sel1").change(function(){
		   var qusn = $("#sel1 option:selected" ).val();
		
			if(qusn=="Text"){
				$(".text").css('display','none');
				document.getElementById('required_add_more').value='' ; 
				document.getElementById('label_add_more').value='' ; 
				$("#required_add_more").prop('required',false);
				$("#label_add_more").prop('required',false);
				$(".field_label_more").prop('required',false);
			}
			if(qusn=="Radio"){
				$(".text").css('display','block');
				$("#required_add_more").prop('required',true);
				$("#label_add_more").prop('required',true);
			}
			if(qusn=="CheckBox"){
				$(".text").css('display','block');
				$("#required_add_more").prop('required',true); 
				$("#label_add_more").prop('required',true); 
			}
		});
	});
</script>




<?php include('notifyjs.php');?>
			
		</body>
		
	</html>
		