<?php 
	error_reporting(0);
	include('config.php');
	$ques_cat_id=$_GET['question_id'];
	$store = $_GET['shop'];
	$select = $con->query("SELECT access_token,id FROM installs WHERE store = '$store'");
	$user = $select->fetch_object();
	$store_access_id = $user->id;
	
	/*---------------delete Option start---------------*/
	if($_GET['ans_delete'] != ""){
		$ans_delete=$_GET['ans_delete'];
		$ans = "DELETE FROM categories_ans WHERE id ='".$ans_delete."'";			
		$ans_resul=mysqli_query($con,$ans);
		if($ans_resul){
			//echo "<script type='text/javascript'>alert('Option Deleted successfully!');</script>";
		}
   }
	/*---------------update form start---------------*/
	
	if(isset($_POST['submit'])){
		$ques_id=$_POST['ques_id'];
		$ques_title=$_POST['ques_title'];
		$in="UPDATE ques_categories SET ques_title = '".$ques_title."' WHERE id = '".$ques_id."'";	
		$res=mysqli_query($con,$in);
		if($res){
			//echo "<script type='text/javascript'>alert('Form submited successfully!');</script>"; 
		}
	 	if($_POST['field_val']){
			$field_ans=$_POST['label_val'];
			$field_val_tags=$_POST['field_val'];
			 $ans_id=$_POST['ans_id'];
			foreach($field_ans as $key=>$value){
				$field_val_tag=strtolower($field_val_tags[$key]);
				$field_val_tag=str_replace(' ', '_', $field_val_tag);				
				$ans_filed="UPDATE categories_ans SET cat_ans = '".$field_ans[$key]."',cat_ans_tag = '".$field_val_tag."' WHERE id ='".$ans_id[$key]."'";
				$ans = mysqli_query($con,$ans_filed);		 											
			} 
			if($ans){
				//echo "<script type='text/javascript'>alert('Form submited successfully!');</script>"; 
			}
		}
		/*---------------update new options start---------------*/
		$reslt ="";	
		if($_POST['label_val_new']){
			$field_ans=$_POST['label_val_new'];
			$field_val_new=$_POST['field_val_new'];
			foreach ($field_ans as $key=>$val) {
				$field_val_tag=strtolower($field_val_new[$key]);
				$field_val_tag=str_replace(' ', '_', $field_val_tag);
				if($val!=''){
					$ans="insert into categories_ans(cat_ans,cat_ans_tag,cat_id,store_access_id)values('".$field_ans[$key]."','".$field_val_tag."','".$ques_id."','".$store_access_id."')";	
					$reslt=mysqli_query($con,$ans);
				}                          
			}
				if($reslt){
					//echo "<script type='text/javascript'>alert('Form submited successfully!');</script>";
				}
		}  
		if($res != "" OR $ans != "" OR $reslt != ""){
					echo "<script type='text/javascript'>alert('Form Updated successfully!');</script>";
		}
		/*---------------update new options end---------------*/
	}
	
/*---------------update form end---------------*/	
	$sql="SELECT * from ques_categories where id ='".$ques_cat_id."'";
	$result=mysqli_query($con,$sql); 
	$row_ques=mysqli_fetch_assoc($result);
	$cat_id = $row_ques['id'];
	$ques_type=$row_ques['ques_type'];
	$ques_title=$row_ques['ques_title'];
?>

<html>
	<head>
	<link rel="stylesheet" href="assets/css/style.css">
		<script src="assets/js/field.jquery.js"></script>
		
	</head>
	<body>
	<?php
include('notifybar.php');
echo $results_ex; 

	if(	$ques_type == "Text"){
		?>
		<style>
		.btnDivMoreBtn{
			visibility:hidden;
		}
		.row.text{
			visibility:hidden;
		}
		</style>
		
	<?php }	?>
		<ul id="navi">
			<li><a class="menu" href="anavii.php?shop=<?php echo $store;?>">Add Question</a></li>
			<li><a  class="menu active" href="view_ques_list.php?shop=<?php echo $store;?>">View Question</a></li>
	    	<li><a  class="menu" href="user_ans_list.php?shop=<?php echo $store;?>">Users View</a></li>
			<li><a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Upgrade</a></li>
			<li><a  class="menu" href="stripe-pay/account_section.php?shop=<?php echo $store;?>">Account Details</a></li>
			<!--<li><a  class="menu" href="view-survey.php">View-Survey</a></li>-->
		</ul>	
		<?php //$quiz_cat_id=$_GET['quiz_cat_id'];?>
	
	<div class="container">
		<div class="backButtn">
		<a class="quiz_back" href="view_ques_list.php?shop=<?php echo $store;?>">Back</a>
		</div>
		<h1 class="headUpdate">Update Questions</h1>
		<p>Question Type: <?php echo $ques_type;?></p>
		<form method="post" enctype="multipart/form-data">
			<div class="qust_page">						  
				<input type="hidden" value="<?php echo $cat_id; ?>" name="ques_id" required>
				<div class="col-25">
					<label>Question</label>
				</div>
				<textarea class="edit_page" name="ques_title" required><?php echo $ques_title;?></textarea>     			 
				<?php
				$sql1 = "SELECT * FROM categories_ans WHERE cat_id ='".$cat_id."'";
				$result1=mysqli_query($con,$sql1);
				$i=1;
				while($row1=mysqli_fetch_assoc($result1))
				{?>			
				<div class="row text">
					<div class="col-25">
						<label>Option <?php echo $i; ?>: </label>
					</div>
					<div class="col-75">
						<div class="col-md-9 input_fields_container">
							<div class="optionfields">
							
								<input class="field_val" type="hidden" value="<?php echo $row1['id'];?>" name="ans_id[]">
								<input class="field_label edit_page"  type="text" value="<?php echo $row1['cat_ans'];?>" name="label_val[]" required>
								<input class="field_val edit_page"  type="text" value="<?php echo $row1['cat_ans_tag'];?>" name="field_val[]" required>
								<a Onclick="return ConfirmDelete();"
								class="remove_text" href="ques_edit.php?ans_delete=<?php echo $row1['id'];?>&question_id=<?php echo $ques_cat_id;?>&shop=<?php echo $store;?>">X</a>
							</div>
						</div>
					</div>
				</div>
				<?php
					$i++;
				}
				?>
				<div class="row text btnDivMoreBtn">
					<div class="col-100">
						<div class="btnDiv"> 
							<a href="javascript:void(0)" class="editAddmoreBtn">Add More Fields</a>
						</div>
					</div>
				</div>
				<div class="row text moreOptions">
					<div class="col-25">
						<label>Options: </label>
					</div>
					<div class="col-75">
						<div class="col-md-9 input_fields_container_edit">
							<div class="">
								<input class="field_val editMore"  type="text" name="label_val_new[]">
								<input class="field_val" id="required_add_more" style="margin-left:6px;" type="text" name="field_val_new[]">
								<button class="btn btn-sm btn-primary add_more_button updateBtn" style="cursor: pointer;">Add More Fields</button>
							</div>
						</div>
					</div>
				</div>
				<input type="submit" value="Submit" name="submit">
			</div>
		</form>	 		
	</div>
		<script>
		
			$(document).ready(function() {
				var max_fields_limit      = 10; //maximum input boxes allowed
			 
				var x = 1; //initlal text box count
				$('.add_more_button').click(function(e){ //on add input button click
					e.preventDefault();
					if(x < max_fields_limit){ //max input box allowed
						x++; //text box increment
						$('.input_fields_container_edit').append('<div class="xtra"><input class="field_val editMore"  type="text" name="label_val_new[]"><input type="text" class="field_val" style="margin-left:6px;" id="required_remove" name="field_val_new[]"/><a Onclick="return ConfirmDelete();" class="remove_field" style="cursor: pointer; ">Remove</a></div>'); //add input box
					}
				 
				});
	 			 $('.input_fields_container_edit').on("click",".remove_field", function(e){
					
					var x = confirm("Are you sure you want to delete?");
					if (x){
						e.preventDefault(); $(this).parent('div').remove(); x--;
						//$("#required_remove").prop('required',false);
						return true;
					}else{
						return false;
					}  
				}); 
				 
				$(document).on("click",".editAddmoreBtn", function(){
					$('.moreOptions').css('display', 'block');
					$('.btnDivMoreBtn').css('display', 'none');
				});		
				
			});


	</script>
	<script>
	$('.optionfields').on("click",".remove_text", function(e){

	  var x = confirm("Are you sure you want to delete?");
	  if (x)
		  
		  return true;
	  else
		return false;
	});
	</script>
	<div id="myModal" class="modal">
  <div class="modal-content">
   <!-- <span class="close">&times;</span>-->
    <p>Your trial period has expire. Please Upgrade Your Plan!</p>
	<a  class="menu" href="stripe-pay/stripe_pay_demo.php?shop=<?php echo $store;?>">Click Here</a>
  </div>

</div>		
<?php
if($auth_user == "expire"){
?>
<script>
// Get the modal
var modal = document.getElementById('myModal');
//alert(modal);
modal.style.display = "block";

</script>
		
<?php
}
?>		

	<?php include('notifyjs.php');?>
	</body>	
</html>
	