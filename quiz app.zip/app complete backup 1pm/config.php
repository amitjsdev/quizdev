<?php
	$username="kbizsoft_quiz_ap";
	$password="admin@123";
	$servername="localhost";
	$database="kbizsoft_quiz_app";
	$con= new mysqli($servername, $username, $password, $database);
	//$conn = mysqli_connect("localhost","contract_shopify","kbiz@123","contract_shopify_app_test");	
	
	
