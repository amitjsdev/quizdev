<?php include('config.php');
//error_reporting(E_ALL & ~E_NOTICE);
include('../config.php');
$store = $_GET['shop'];

   ?>
<html>
	<head>
	<link rel="stylesheet" href="../assets/css/style.css">
		<script src="../assets/js/field.jquery.js"></script>
		<Style>
		 #page_a_link
 {
  font-family: arial, verdana;
  font-size: 12px;
  border:1px #000000 solid;
  color: #ff0000;
  background-color: #cccccc;
  padding: 6px;
  margin: 3px;
  text-decoration: none;
 }
		</style>
	</head>
	<body>
<?php
//include('../notifybar.php');
echo $results_ex; 
?>
		<ul id="navi">
			<li><a class="menu" href="../anavii.php?shop=<?php echo $store;?>">Add Question</a></li>
			<li><a  class="menu" href="../view_ques_list.php?shop=<?php echo $store;?>">View Question</a></li>
	    	<li><a  class="menu" href="../user_ans_list.php?shop=<?php echo $store;?>">Users View</a></li>
			<li><a  class="menu" href="stripe_pay_demo.php?shop=<?php echo $store;?>">Upgrade</a></li>
	    	<li><a  class="menu active" href="account_section.php?shop=<?php echo $store;?>">Account Deatils</a></li>
		</ul>	
		
		<div class="questionLists">
		 <?php
				  if($_GET['payment'] =="success"){
					  
					  ?>
					   <span class="payment-sucess">Successful Payment</span>
					  
				  <?php
				  }?>
		<h1 class="headUpdate">List Of All Payments</h1>
            <div class="ui-card__section">
				<div class="ui-type-container">
                    <div class="table-wrapper">
					<?php 
					$perpage = 15;
					if(isset($_GET["page"])){
						$page = intval($_GET["page"]);
					}
					else {
						$page = 1;
					}
					$calc = $perpage * $page;
					$start = $calc - $perpage;
					$result = mysqli_query($con, "select * from payments WHERE store_url ='".$store."' order by id desc Limit $start, $perpage");
					$rows = mysqli_num_rows($result);
					if($rows){
					$i = 0;					
					?>
						<table class="table_main">
							<thead>
								<tr class="trtop_gapiheading main_porduct_table">
								<th style="width: 5%;">Sr No.</th>
								<th>Transcation Id</th>
								<th>Amount</th>
								<th>Start Date</th>
								<th>End Date</th>
								</tr>
							</thead>
							 <tbody>
							<?php
							$b=1;
							while($row=mysqli_fetch_assoc($result)){
								$amount = $row['payment_amount']/100;
								
							?>
								<tr class="tr_table">
									<td><?php echo $b;?></td>
									<td><?php echo $row['txnid'];?></td>
									<td>$<?php echo $amount;?></td>
									<td><?php echo date('d/m/Y H:i:s', $row['createdtime']);?></td>
									<td><?php echo date('d/m/Y H:i:s', $row['endtime']);?></td>
								</tr>

							<?php
							$b++;
							}
							?>
							</tbody>
						</table>
						
<table width="400" cellspacing="2" cellpadding="2" align="center">
<tbody>
<tr>
<td align="center">

<?php

if(isset($page))

{

$result = mysqli_query($con,"select Count(*) As Total from payments");

$rows = mysqli_num_rows($result);

if($rows)

{

$rs = mysqli_fetch_assoc($result);

$total = $rs["Total"];

}

$totalPages = ceil($total / $perpage);

if($page <=1 ){

echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";

}

else

{

$j = $page - 1;

echo "<span><a id='page_a_link' href='account_section.php?page=$j&shop=$store'>Prev</a></span>";

}

for($i=1; $i <= $totalPages; $i++)

{

if($i<>$page)

{

echo "<span><a id='page_a_link' href='account_section.php?page=$i&shop=$store'>$i</a></span>";

}

else

{

echo "<span id='page_links' style='font-weight: bold;'>$i</span>";

}

}

if($page == $totalPages )

{

echo "<span id='page_links' style='font-weight: bold;'>Next</span>";

}

else

{

$j = $page + 1;

echo "<span><a id='page_a_link' href='account_section.php?page=$j&shop=$store'>Next</a></span>";

}

}

?></td>
<td></td>
</tr>
</tbody>
</table>

						<?php
					}else{
						?>
						<h2 class="emptyRecords" >No records found!</h2>
						<?php
					}
						?>
					</div>
				</div>
			</div>
		</div>
<?php include('../notifyjs.php');?>

	</body>
</html>