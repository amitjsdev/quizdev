<?php

require_once('./config.php');
  require_once('lib/Customer.php');


$cu = \Stripe\Customer::retrieve( "cus_E0vhcEUiiGCrx3" );

/* echo "<pre>";
print_r($cu); */

$result = $cu->subscriptions->data;

/* echo "<pre>";
print_r($result);
 include('../config.php'); */
//error_reporting(E_ALL & ~E_NOTICE);
include('../config.php');
//$store = $_GET['shop'];

 $sql = "select * FROM payments WHERE store_url = 'kbiz-avanii.myshopify.com' order by id desc";

	$value_result = $con->query($sql);
$cust_id = $value_result->fetch_object();
$custmer_id = $cust_id->itemid;

	




   ?>
<html>
	<head>
	<link rel="stylesheet" href="../assets/css/style.css">
		<script src="../assets/js/field.jquery.js"></script>
	</head>
	<body>
<?php

//include('../config.php');
//include('../notifybar.php');
echo $results_ex; 
?>

		
		<div class="questionLists">
		 <?php
				  if($_GET['payment'] =="success"){
					  
					  ?>
					   <span class="payment-sucess">Successful Payment</span>
					  
				  <?php
				  }?>
		<h1 class="headUpdate">List Of All Payments</h1>
            <div class="ui-card__section">
				<div class="ui-type-container">
                    <div class="table-wrapper">
					<?php 
					$user_id = array();
					$sql="SELECT * FROM payments WHERE store_url ='".$store."'";
					$result=mysqli_query($con,$sql);
					$row_count= $result->num_rows;
					if($row_count != 0){
						
					?>
						<table class="table_main">
							<thead>
								<tr class="trtop_gapiheading main_porduct_table">
								<th>Sr No.</th>
								<th>Transcation Id</th>
								<th>Amount</th>
								<th>Start Date</th>
								<th>End Date</th>
								</tr>
							</thead>
							 <tbody>
							<?php
							$i=1;
							while($row=mysqli_fetch_assoc($result)){
								$amount = $row['payment_amount']/100;
								
	?>
								<tr class="tr_table">
									<td><?php echo $i;?></td>
									<td><?php echo $row['txnid'];?></td>
									<td>$<?php echo $amount;?></td>
									<td><?php echo date('d/m/Y H:i:s', $row['createdtime']);?></td>
									<td><?php echo date('d/m/Y H:i:s', $row['endtime']);?></td>
								</tr>

							<?php
							$i++;
							}
							?>
							</tbody>
						</table>
						<?php
					}else{
						?>
						<h2 class="emptyRecords" >No records found!</h2>
						<?php
					}
						?>
					</div>
				</div>
			</div>
		</div>
<?php include('../notifyjs.php');?>

	</body>
</html>
