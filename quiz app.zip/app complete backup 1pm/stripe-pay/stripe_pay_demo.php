<html lang="en">
<head>
<meta charset="UTF-8">
<title>Stripe Pay</title>
	<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php
 $store = $_GET['shop'];

include('../config.php');
//include('../notifybar.php');
//echo $results_ex;  
?>
<ul id="navi">
	    	<li><a class="menu" href="../anavii.php?shop=<?php echo $store;?>">Add Question</a></li>
	    	<li><a  class="menu" href="../view_ques_list.php?shop=<?php echo $store;?>">View Question</a></li>
	    	<li><a  class="menu" href="../user_ans_list.php?shop=<?php echo $store;?>">Users View</a></li>
	    	<li><a  class="menu active" href="stripe_pay_demo.php?shop=<?php echo $store;?>">Upgrade</a></li>
	    	<li><a  class="menu" href="account_section.php?shop=<?php echo $store;?>">Account Deatils</a></li>
			<!--<li><a  class="menu" href="view-survey.php">View-Survey</a></li>-->
		</ul>
	<div class="container">
		<div class="backButtn">
			<a class="quiz_back" href="javascript: history.go(-1)" target="_self">Back</a>
		</div>
		<h1 class="headUpdate">Stripe Payment</h1>			
				<div class="dropin-page">
				  <form action="charge.php" method="POST" id="payment-form" onsubmit="return onSubmitDo()">
				  <input type="hidden" name="shop" value="<?php echo $store;?>">
				  <span class="payment-errors"></span>
				  <div class="form-row">
					<label>
					  <span>Card Number</span>
					</label> 
					  <input type="text" class="stripeCard" size="20" data-stripe="number" required>
				
				  </div>

				  <div class="form-row">
					<label>
					  <span>Expiration (MM)</span>
					 </label> 
					  <input type="text" size="2" data-stripe="exp_month" required>
					  </div>
					<div class="form-row">
					
					<label>
					  <span>Expiration (YY)</span>
					 </label> 
					<input type="text" class="stripeyy" size="2" data-stripe="exp_year" required>
				  </div>

				  <div class="form-row">
					<label>
					  <span>CVC</span>
					 </label> 
					  <input type="text" class="stripeCvc" size="4" data-stripe="cvc" required>
					
				  </div>
				   <div class="form-row">
					<label>
					  <span>Email Address</span>
					 </label> 
					  <input type="email" class="stripeEmail" size="4" name="emailAddress" required>
					
				  </div>
				  <button type="submit">Submit Payment</button>
				</form>
				  <span style='color: red' id='payment-error'></span>
				</div>
	</div>
	<div style="position:absolute;top:50%;left:50%;" class="loader"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<!-- TO DO : Place below JS code in js file and include that JS file -->
  <script type="text/javascript">
  
    Stripe.setPublishableKey('pk_test_iFUDaRmSMQYQdtunRHzsrADa');
    
    function onSubmitDo () {
		
		    document.getElementsByClassName('loader')[0].style.display = 'block';
			$('.container').css('opacity', '0.1');

      
      Stripe.card.createToken( document.getElementById('payment-form'), myStripeResponseHandler );
          
      return false;
      
    };

    function myStripeResponseHandler ( status, response ) {
      
      console.log( status );
      console.log( response );
    
      if ( response.error ) {
        document.getElementById('payment-error').innerHTML = response.error.message;
		$('.container').css('opacity', '1');
		$('.loader').css('display', 'none');
      } else {
        var tokenInput = document.createElement("input");
        tokenInput.type = "hidden";
        tokenInput.name = "stripeToken";
        tokenInput.value = response.id;

        var paymentForm = document.getElementById('payment-form');
        paymentForm.appendChild(tokenInput);

        paymentForm.submit();
      }
      
   };
      
       </script>
<?php include('../notifyjs.php');?>

</body>
</html>