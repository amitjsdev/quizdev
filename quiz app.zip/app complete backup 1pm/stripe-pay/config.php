<?php
require_once('../vendor/autoload.php');
require_once('init.php');

$stripe = array(
  "secret_key"      => "sk_test_NMq1VxAaD1opQ2RkozLE0oyh",
  "publishable_key" => "pk_test_iFUDaRmSMQYQdtunRHzsrADa"
);
\Stripe\Stripe::setApiKey('sk_test_NMq1VxAaD1opQ2RkozLE0oyh');
//Stripe::setApiKey($stripe['secret_key']);
?>
