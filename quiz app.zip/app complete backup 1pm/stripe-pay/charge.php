<?php
require_once('./config.php');
  require_once('lib/Customer.php');
  
  //$getStore=$_GET['shop'];

	if(isset($_POST['stripeToken'])){
	
		$token  = $_POST['stripeToken'];
		$email  = $_POST['emailAddress'];

		include('../config.php');
		
		$getStore=$_POST['shop'];
		$sql = "select * FROM payments WHERE store_url = '".$getStore."' order by id desc";
		$value_result = $con->query($sql);
		$cust_id = $value_result->fetch_object();
		$custmer_id = $cust_id->itemid;
		if($custmer_id){
			$subscription = \Stripe\Subscription::create(array(
				"customer" => $custmer_id,
				"plan" => "app_plan"
			)); 
		}else{
			$customer = \Stripe\Customer::create(array(
				"email" => $email,
				"source" => $token,
			));
				$subscription = \Stripe\Subscription::create(array(
				"customer" => $customer->id,
				"plan" => "app_plan"
			)); 	
		}
		$getStore=$_POST['shop'];
			$txn_id = $subscription->id;
			$current_period_start = $subscription->current_period_start;
			$current_period_end = $subscription->current_period_end;
			$payment_amount = $subscription->plan->amount;
			$payment_status =$subscription->plan->active;
			$item_number = $subscription->customer;
			$item_name = $subscription->plan->interval;
			$payment_currency =$subscription->plan->currency;
			$end_date = date('Y-m-d', $current_period_end);
			$result = "INSERT INTO `payments` (txnid,payment_amount,payment_status,itemid,item_name,payment_currency,store_url,createdtime,endtime) VALUES('$txn_id','$payment_amount','$payment_status','$item_number','$item_name','$payment_currency','$getStore','$current_period_start','$current_period_end')";
			$reslt=mysqli_query($con,$result); 
			$payment_id=$con->insert_id;
				//$getStore=$_GET['shop'];
				if($payment_id){
					$sql_update_api = "UPDATE app_check set status ='1',end_date = '".$end_date."' where store_url ='".$getStore."'";  
					$sq_update = $con->query($sql_update_api); 
					echo "<script>window.location = 'https://kbizsoft.com/dev/app/quiz_shopify/stripe-pay/account_section.php?shop=".$getStore."&payment=success'</script>";
				}  
			//exit;
		/*  if($subscription->id;){
			echo "<script>window.location = 'https://kbizsoft.com/dev/app/quiz_shopify/stripe-pay/stripe_pay_demo.php?shop=".$getStore."'</script>";
		}  */
	}
	
  
?>